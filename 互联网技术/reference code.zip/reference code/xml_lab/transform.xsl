<?xml version="1.0" encoding="UTF-8"?> <!-- 声明这是一个 XML 文档，采用 UTF-8 编码 -->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"> <!-- 定义 XSLT 样式表的根节点，并声明 XSLT 的官方命名空间 -->
    
    <xsl:output method="html" encoding="UTF-8" indent="yes" /> <!-- 指令：告诉浏览器或转换引擎，最终输出的格式是 HTML，并且要求代码自动缩进(indent="yes")排版整齐 -->
    
    <!-- === 第一部分：定义一个用于计算加权总分的“函数”（命名模板） === -->
    <xsl:template name="calcWeightedSum"> <!-- 定义一个名为 calcWeightedSum 的模板（类似于各种编程语言里的 function 函数） -->
        <xsl:param name="index" select="1" /> <!-- 定义传入参数 index（当前循环索引），默认值为 1 -->
        <xsl:param name="currentSum" select="0" /> <!-- 定义传入参数 currentSum（当前累加的乘积总和），默认值为 0 -->
        
        <xsl:variable name="totalNodes" select="count(/profile/courses/course)" /> <!-- 声明一个变量 totalNodes，使用 count() 算出 XML 中共有多少门课程 -->
        
        <xsl:choose> <!-- 开始条件判断（相当于代码里的 switch 或 if-else 语句） -->
            <xsl:when test="$index &lt;= $totalNodes"> <!-- 当条件成立：当前索引 <= 课程总数时（&lt; 是小于号 < 的转义符） -->
                <xsl:variable name="currNode" select="/profile/courses/course[$index]" /> <!-- 声明变量 currNode，提取出当前索引对应的那一门课程节点 -->
                <xsl:call-template name="calcWeightedSum"> <!-- 核心动作：递归调用本模板自己（相当于 for/while 循环继续下一次） -->
                    <xsl:with-param name="index" select="$index + 1" /> <!-- 把索引加 1 后传给下一次调用 -->
                    <xsl:with-param name="currentSum" select="$currentSum + ($currNode/hours * $currNode/score)" /> <!-- 算出当前课程的 (学时*成绩) 并累加到总和中传下去 -->
                </xsl:call-template> <!-- 结束递归调用 -->
            </xsl:when> <!-- 结束条件成立的分支 -->
            <xsl:otherwise> <!-- 否则（即索引大于总数，说明所有课程都算完了） -->
                <xsl:value-of select="$currentSum" /> <!-- 将最终累加好的总和输出打印出来 -->
            </xsl:otherwise> <!-- 结束否则分支 -->
        </xsl:choose> <!-- 结束条件判断 -->
    </xsl:template> <!-- 结束这个命名模板 -->

    <!-- === 第二部分：页面的主渲染入口 === -->
    <xsl:template match="/"> <!-- match="/" 表示从 XML 的最顶层根节点开始匹配，这是页面渲染的起点 -->
        <html> <!-- 开始生成 HTML 页面的根标签 -->
        <head> <!-- HTML 头部开始 -->
            <title>个人信息与成绩单 (XML+XSLT)</title> <!-- 设置网页标题 -->
            <style> <!-- 开始插入 CSS 样式表，用于美化生成的 HTML 网页 -->
                body { font-family: "Microsoft YaHei", sans-serif; background: #f4f7f6; padding: 20px; } <!-- 设置网页全局字体、浅灰背景色和内边距 -->
                .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); border-radius: 8px; } <!-- 居中的白色卡片容器，带阴影和圆角 -->
                .basic-info { display: flex; align-items: center; gap: 20px; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 2px solid #eee; } <!-- 个人信息区使用 Flex 弹性布局，底部加一条分割线 -->
                img { width: 120px; height: 160px; object-fit: cover; border: 1px solid #ccc; } <!-- 控制照片尺寸，cover 保证照片不变形 -->
                .text-info p { margin: 8px 0; font-size: 16px; } <!-- 设置文字段落的间距和字体大小 -->
                table { width: 100%; border-collapse: collapse; margin-top: 20px; } <!-- 设置表格宽度 100%，合并单元格边框 -->
                th, td { border: 1px solid #ccc; padding: 10px; text-align: center; } <!-- 设置表格单元格的边框、内边距和文字居中 -->
                th { background-color: #0056b3; color: white; } <!-- 设置表头为深蓝色背景，白色文字 -->
                .highlight { font-weight: bold; color: #d9534f; font-size: 18px; } <!-- 用于高亮最后计算出的大字号平均分 -->
            </style> <!-- CSS 样式表结束 -->
        </head> <!-- HTML 头部结束 -->
        <body> <!-- HTML 主体开始 -->
            <div class="container"> <!-- 页面主容器 -->
                <h2>个人基本信息</h2> <!-- 个人信息区标题 -->
                
                <div class="basic-info"> <!-- 包裹照片和文字的容器 -->
                    <div> <!-- 照片容器 -->
                        <img> <!-- HTML 图片标签，注意这里没有直接写 src 属性 -->
                            <xsl:attribute name="src"> <!-- 关键点：使用 xsl:attribute 动态为外层的 img 标签添加 src 属性 -->
                                <xsl:value-of select="profile/basicInfo/photo"/> <!-- 读取 XML 中对应路径下的照片文件名，填入 src 中 -->
                            </xsl:attribute> <!-- 属性设置结束 -->
                        </img> <!-- 图片标签结束 -->
                    </div>
                    <div class="text-info"> <!-- 文字信息容器 -->
                        <!-- xsl:value-of 用于提取 XML 节点中的文本内容并打印在 HTML 页面上 -->
                        <p><strong>学号：</strong> <xsl:value-of select="profile/basicInfo/studentID"/></p> <!-- 提取并显示学号 -->
                        <p><strong>姓名：</strong> <xsl:value-of select="profile/basicInfo/name"/></p> <!-- 提取并显示姓名 -->
                        <p><strong>班级：</strong> <xsl:value-of select="profile/basicInfo/class"/></p> <!-- 提取并显示班级 -->
                        <p><strong>兴趣爱好：</strong> <xsl:value-of select="profile/basicInfo/hobbies"/></p> <!-- 提取并显示兴趣爱好 -->
                    </div>
                </div>

                <h2>课程成绩表 (按成绩升序排列)</h2> <!-- 成绩单区域标题 -->
                <table> <!-- HTML 表格开始 -->
                    <tr> <!-- 表格首行（表头） -->
                        <th>课程名称</th> <!-- 表头列：课程名称 -->
                        <th>学时</th> <!-- 表头列：学时 -->
                        <th>成绩</th> <!-- 表头列：成绩 -->
                    </tr>
                    
                    <xsl:for-each select="profile/courses/course"> <!-- 核心语法：遍历 XML 中所有的 course 节点 -->
                        <xsl:sort select="score" data-type="number" order="ascending"/> <!-- 核心要求：在遍历输出前，先按照 score 节点的值以数字类型(number)进行升序(ascending)排列 -->
                        <tr> <!-- 为每一门遍历到的课程生成一个表格数据行 -->
                            <td><xsl:value-of select="courseName"/></td> <!-- 提取当前课程的名称放入单元格 -->
                            <td><xsl:value-of select="hours"/></td> <!-- 提取当前课程的学时放入单元格 -->
                            <td><xsl:value-of select="score"/></td> <!-- 提取当前课程的成绩放入单元格 -->
                        </tr> <!-- 当前课程数据行结束 -->
                    </xsl:for-each> <!-- 遍历所有课程结束 -->
                </table> <!-- HTML 表格结束 -->

                <div style="margin-top: 20px; text-align: right;"> <!-- 底部计算结果容器，文字靠右对齐 -->
                    <!-- 声明变量 totalHours，使用 XPath 内置的 sum() 函数直接把所有课程的 hours 节点值加起来 -->
                    <xsl:variable name="totalHours" select="sum(profile/courses/course/hours)" /> 
                    
                    <xsl:variable name="weightedSum"> <!-- 声明变量 weightedSum 用来保存总乘积 -->
                        <xsl:call-template name="calcWeightedSum" /> <!-- 调用我们写在最上面的 calcWeightedSum 模板，执行递归计算 -->
                    </xsl:variable> <!-- 递归计算返回的结果将保存在 weightedSum 变量中 -->
                    
                    <!-- 声明变量 average，计算平均分。注意：XSLT 中的除法符号必须写成英文单词 'div'，不能用 '/'（因为 '/' 被用于表示路径了） -->
                    <xsl:variable name="average" select="$weightedSum div $totalHours" /> 
                    
                    <p>总学时：<xsl:value-of select="$totalHours" /></p> <!-- 打印刚才算出来的总学时 -->
                    <!-- 打印平均分。使用 format-number 函数对结果进行格式化，'#.00' 表示强制保留两位小数 -->
                    <p class="highlight">加权平均分：<xsl:value-of select="format-number($average, '#.00')" /></p> 
                </div> <!-- 底部计算结果容器结束 -->
            </div> <!-- 页面主容器结束 -->
        </body> <!-- HTML 主体结束 -->
        </html> <!-- HTML 根标签结束 -->
    </xsl:template> <!-- 主渲染模板结束 -->
</xsl:stylesheet> <!-- 整个 XSLT 样式表结束 -->