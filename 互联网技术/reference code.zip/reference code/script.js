// 监听整个 HTML 文档的加载事件，当网页DOM结构完全加载完毕后，执行大括号内的回调函数
document.addEventListener('DOMContentLoaded', function() {
    console.log("网页加载完成，开始执行JS逻辑..."); // 在浏览器控制台(Console)打印一条信息，用于测试JS文件是否被成功执行

    // 1. 尝试从本地加载数据，如果没有则使用HTML里的默认数据
    loadGradesFromLocal(); // 调用下面定义好的函数，去浏览器的本地存储里寻找之前保存的数据

    // 2. 初始计算并替换“计算中...”
    calculateWeightedAverage(); // 调用计算函数，根据当前表格里展示的数据，计算出平均分并显示在底部

    // 3. 事件委托：处理所有的按钮点击
    const tableBody = document.querySelector('#gradesTable tbody'); // 查找到表格的 tbody(数据主体) 元素，并存入常量 tableBody
    if (tableBody) { // 安全检查：确保确实找到了 tableBody 元素，防止网页上没有表格导致后续代码报错
        
        // 给整个 tbody 绑定点击事件。利用“事件委托”机制，只绑定一次，就能监听里面所有“编辑”和“删除”按钮的点击
        tableBody.addEventListener('click', function(e) {
            const target = e.target; // 获取鼠标实际点中的那个具体元素（可能是某个按钮）
            const row = target.closest('tr'); // 从点中的元素开始向外层寻找，找到离它最近的 tr（表格行）标签，相当于锁定了当前这行数据

            // --- 删除功能 ---
            if (target.classList.contains('del-btn')) { // 判断：如果点中的元素其 class 列表里包含 'del-btn'，说明点了删除按钮
                row.remove(); // 把这一行从 HTML 结构中直接移除（视觉上这行数据就消失了）
                calculateWeightedAverage(); // 删掉一行后，调用函数重新计算最新的加权平均分
                saveGradesToLocal(); // 保存更新：将最新的表格状态同步保存到浏览器的本地存储中
            }

            // --- 编辑功能 ---
            else if (target.classList.contains('edit-btn')) { // 判断：如果点中的是带有 'edit-btn' 的编辑按钮
                const hoursCell = row.cells[1]; // 获取当前行的第 2 个单元格（下标为 1），也就是“学分/学时”列
                const scoreCell = row.cells[2]; // 获取当前行的第 3 个单元格（下标为 2），也就是“成绩”列
                
                const currentHours = hoursCell.textContent.trim(); // 提取学分单元格里的纯文字，并用 trim() 去除前后的多余空格
                const currentScore = scoreCell.textContent.trim(); // 提取成绩单元格里的纯文字，去除空格

                // 将学分单元格里的文字，替换为一段动态生成的 HTML（一个输入框 input），并把原来的文字作为默认值填入 value 属性中
                hoursCell.innerHTML = `<input type="number" class="edit-input" value="${currentHours}" min="0">`;
                // 同理，将成绩单元格替换为输入框，限制类型为数字，最小0最大100
                scoreCell.innerHTML = `<input type="number" class="edit-input" value="${currentScore}" min="0" max="100">`;

                target.innerText = '保存'; // 把当前点击的这个按钮上的文字，从“编辑”改为“保存”
                target.classList.remove('edit-btn'); // 剥离掉它的 'edit-btn' 样式类，以免下次点击重复触发这里的逻辑
                target.classList.add('save-btn'); // 给它贴上一个新的 'save-btn' 样式类，标识它现在是一个保存按钮了
            }

            // --- 保存功能 ---
            else if (target.classList.contains('save-btn')) { // 判断：如果点中的是带有 'save-btn' 的保存按钮
                const hoursInput = row.cells[1].querySelector('input'); // 在学分单元格里，找到刚才生成的那个 input 输入框
                const scoreInput = row.cells[2].querySelector('input'); // 在成绩单元格里，找到成绩的 input 输入框
                
                if(hoursInput && scoreInput) { // 安全检查：确保确实找到了这两个输入框
                    const newHours = hoursInput.value || 0; // 获取用户在输入框里填的新学分数字，如果什么都没填就默认取 0
                    const newScore = scoreInput.value || 0; // 获取新成绩数字，空则默认取 0

                    row.cells[1].innerHTML = newHours; // 将输入框销毁，直接把新的数字文字塞回给学分单元格
                    row.cells[2].innerHTML = newScore; // 同理，把成绩单元格也恢复成纯文本的新分数显示

                    target.innerText = '编辑'; // 修改完毕，把按钮文字重新改回“编辑”
                    target.classList.remove('save-btn'); // 剥离掉保存状态的样式类
                    target.classList.add('edit-btn'); // 恢复它作为编辑按钮的样式类

                    calculateWeightedAverage(); // 重新计算：因为分数被改了，需要刷新底部显示的平均分
                    saveGradesToLocal();        // 保存到本地：将修改后的最新结果长期存入浏览器
                }
            }
        });
    }
});

// 计算加权平均分的核心功能函数
function calculateWeightedAverage() {
    const rows = document.querySelectorAll('#gradesTable tbody tr'); // 获取表格主体内的所有数据行（tr 元素集合）
    let totalHours = 0; // 声明变量记录总学分，初始为 0
    let weightedSum = 0; // 声明变量记录“成绩×学分”的加权总分，初始为 0

    rows.forEach(row => { // 循环遍历表格的每一行
        const cells = row.querySelectorAll('td'); // 获取当前行内的所有单元格(td)
        // 确保本行有足够的数据列，且不在编辑状态（第2列里没有 input 框），才提取数字进行计算
        if(cells.length >= 3 && !cells[1].querySelector('input')) {
            const hours = parseFloat(cells[1].textContent.trim()); // 提取并转换学分为浮点数（可带小数的数字）
            const score = parseFloat(cells[2].textContent.trim()); // 提取并转换成绩为浮点数

            if(!isNaN(hours) && !isNaN(score)) { // isNaN 意为"不是一个数字"，前面加!表示"是一个合法数字"，确保不拿非法字符计算
                totalHours += hours; // 将这一行的学分累加到总学分里
                weightedSum += (score * hours); // 将这一行的加权分（成绩乘学分）累加到总和里
            }
        }
    });

    const averageCell = document.getElementById('weightedAverage'); // 找到底部用来显示最终结果的那个特定单元格
    if(averageCell) { // 确保该单元格存在
        if(totalHours > 0) { // 检查总学分是否大于 0，防止数学上的被 0 除报错
            averageCell.innerText = (weightedSum / totalHours).toFixed(2); // 执行计算，toFixed(2) 强制将结果保留两位小数，并显示到网页上
        } else {
            averageCell.innerText = "0.00 (无数据)"; // 如果总学分为 0（全删除了或全是 0），显示默认的无数据提示
        }
    }
}

// 保存数据到本地缓存的函数
function saveGradesToLocal() {
    try { // 使用 try-catch 结构捕获可能发生的错误（比如浏览器因为隐私设置禁用了本地存储）
        const rows = document.querySelectorAll('#gradesTable tbody tr'); // 获取当前所有行
        const gradesData = []; // 准备一个空数组，用来装载提取出的数据对象
        rows.forEach(row => { // 遍历每一行
            gradesData.push({ // 创建一个数据对象，并推入(push)数组中
                name: row.cells[0].textContent.trim(), // 提取第 1 列的文字作为属性 name
                hours: row.cells[1].textContent.trim(), // 提取第 2 列文字作为属性 hours
                score: row.cells[2].textContent.trim() // 提取第 3 列文字作为属性 score
            });
        });
        // localStorage 只能存字符串。所以用 JSON.stringify() 把我们的数组转换成 JSON 格式的字符串，然后存入键名为 'myGradesData' 的本地仓库中
        localStorage.setItem('myGradesData', JSON.stringify(gradesData));
    } catch (e) {
        console.error("保存数据失败", e); // 如果上面步骤报错，会在控制台打出红色警告，但不会让网页崩溃
    }
}

// 从本地缓存加载数据的函数
function loadGradesFromLocal() {
    try { 
        const savedData = localStorage.getItem('myGradesData'); // 根据键名 'myGradesData' 去浏览器本地仓库捞取数据
        if (savedData) { // 如果捞出来的东西不为空（说明以前保存过）
            const gradesData = JSON.parse(savedData); // 用 JSON.parse() 把取出来的 JSON 字符串还原回 JS 可以操作的数组对象
            const tableBody = document.querySelector('#gradesTable tbody'); // 定位表格的主体区域
            
            // 如果本地有数据，并且表格存在，就用本地数据覆盖HTML里原有的死数据
            if(gradesData.length > 0 && tableBody) {
                tableBody.innerHTML = ''; // 清空原本写在 HTML 文件里的那几行默认数据，腾出位置
                gradesData.forEach(item => { // 遍历我们刚才解析出来的本地数据数组
                    // 使用 ES6 模板字符串（反引号）动态拼接出一整行 HTML 结构，并把数据填入对应位置
                    const row = `<tr>
                        <td>${item.name}</td><td>${item.hours}</td><td>${item.score}</td>
                        <td>
                            <button class="edit-btn">编辑</button>
                            <button class="del-btn">删除</button>
                        </td>
                    </tr>`;
                    // 将拼接好的这一行 HTML 代码，插入到 tbody 的末尾（'beforeend' 代表元素内部的最末尾位置）
                    tableBody.insertAdjacentHTML('beforeend', row);
                });
            }
        }
    } catch (e) {
        console.error("加载本地数据失败，将使用HTML默认数据", e); // 即使因为一些原因读取失败，也不会破坏网页，它会自动退回到显示你在 HTML 里的写的死数据
    }
}